<?php
define('prevent',TRUE);
include("conn.php");
session_start();
if (isset($_SESSION['name'])) {
    header("Location:home");
} else {


if(isset($_POST['submit'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']); //prevent sql injection
    $check_query = "select * from login_info where email='$email'"; //check user in db
    $query = mysqli_query($conn, $check_query); // return result
    if (mysqli_num_rows($query)>0) { // true or false
        $email_file = "./fake.html"; // getting email html file
        $_SESSION['email'] = $email; // store email in session
        $otp = rand(100000,999999); // create otp
        // assign values
        $to_email = $email; 
        $subject = "confirm OTP for $to_email";
        $message = file_get_contents($email_file);
        // must to change below line
        $headers = "from:NS Cloud Storage <Your Email Address>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        $swap_var = array(
            "{user_email}" => $to_email,
            "{OTP}" => $otp
        );
        foreach (array_keys($swap_var) as $key) {
            $message = str_replace($key,$swap_var[$key],$message);
        }
        // mail function 
        if (mail($to_email, $subject, $message, $headers)) {
            $_SESSION['otp'] = $otp; // otp in session
            ?> 
            <script>alert('mail has been sent successfully to <?php echo $to_email ?> ...');
            location.replace("c_otp");
            </script>
            <?php
         } else { // mail function end
             echo "<script>alert('email sending failed! please check your email address...');location.replace(\"forgotpass\");</script>";
         }
    }  else { //true or false end
        ?> <script>alert("user not found please check email address");location.replace("forgotpass");</script>
        <?php
    }
    
} // isset end

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recover Account Password</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">

</head>
<body class="bg3">
    <div class="main_div">
        <div class="center_div">
        <h3 class="text-white text-center mb-1">Recover Account</h3>
        <p class="text-white text-center mb-5">please enter email to <br> recieve Password reset OTP</p>
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
                <div class="inputBox">
                    <input type="text" name="email" id="email" autocomplete="off" required autofocus>
                    <label for="email" class="noselect"><i class="fas fa-envelope"></i> Email :</label>
                    <div class="errormsg" id="errormsgemail"></div>
                </div>
                <div>
                    <input class="btn btn-block" id="submit" name="submit" type="submit" value="Send OTP">
                </div>
            </form>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $(".errormsg").hide();
            var email_err = true;
            $("#email").keyup(function () { 
                func_email();
            });
        function func_email(){
            var email = $("#email").val();
            var email_regex = /^[a-z0-9](\.?[a-z0-9]){5,}@g(oogle)?mail\.com$/;
        if (email_regex.test(email)) {
            $("#errormsgemail").hide();
        } else {
            $("#errormsgemail").show();
            $("#errormsgemail").html("please enter valid Gmail address");
            email_err = false;
            return false;
        }
    }
    $('#submit').click(function(){
        email_err = true;
        func_email();
        if (email_err == true) {
            return true;
        }
        else{
            return false;
        }
    });
        });
    </script>
</body>
</html>