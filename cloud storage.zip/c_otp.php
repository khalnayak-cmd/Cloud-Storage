<?php
session_start();
define('prevent',TRUE);
include("conn.php");
if (isset($_SESSION['otp'])) {
    if (isset($_POST['submit'])) {
        $otp = mysqli_real_escape_string($conn , $_POST['otp']);
        $email = $_SESSION['email'];
        if ($_SESSION['otp'] == $otp) {
            $query = mysqli_query($conn, "select * from login_info where email = '$email'");
            $_SESSION['id'] = mysqli_fetch_assoc($query)['id'];
            unset($_SESSION['email']);
            unset($_SESSION['otp']);
            header("Location:reset_pass");
        } else {
            ?>
            <script>alert("incorrect otp please check your email again")</script>
            <?php
        }   
    } 
}else {
    header("Location:forgotpass");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>verify your OTP</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">

</head>
<body class="bg3">
    <div class="main_div">
        <div class="center_div">
        <h3 class="text-white text-center mb-1">verify OTP</h3>
        <p class="text-white text-center mb-3" style="font-size:13px">please enter otp to  reset your password  
         </p> 
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
                <div class="inputBox">
                    <input type="text" oninput="numberOnly(this.id);" maxlength="6" name="otp" id="otp" autocomplete="off" required autofocus >
                    <label for="otp" class="noselect"><i class="fa fa-key"></i> OTP :</label>
                    <div class="errormsg" id="errormsgemail"></div>
                </div>
                <div>
                    <input class="btn btn-block" id="btnsubmit" name="submit" type="submit" value="Confirm Otp">
                
                </div>
            </form>
        </div>
    </div>
    <script>
    function numberOnly(id) {
    var element = document.getElementById(id);
    var regex = /[^0-9]/gi;
    element.value = element.value.replace(regex, "");
    }
</script>
</body>
</html>