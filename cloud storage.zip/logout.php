<?php

if (isset($_POST['logout'])) {

    session_start();

    session_destroy();

    header("location:index");

} else {
    header("Location:home");
}


?>