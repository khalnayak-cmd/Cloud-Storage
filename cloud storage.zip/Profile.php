<?php 
session_start(); 
define('prevent',TRUE);
include("conn.php");
    if (!isset($_SESSION['name'])) {
      header("location:index");
} 
$dir = $_SESSION['username']."/";
$uname = $_SESSION['username'];
$select_query = mysqli_query($conn, "select * from login_info where username='$uname' ");
$fetch_arr = mysqli_fetch_assoc($select_query);
if (isset($_POST['submit'])) {
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $select_query_email = mysqli_query($conn,"select * from login_info where email ='$email' ");
  $upate_q =  "update login_info set email='$email' where username='$uname'";
  if ($email != $fetch_arr['email']) {
    if(mysqli_num_rows($select_query_email) > 0){
      ?>
          <script>
            alert("email linked to another account \n please choose another email");
          location.replace("profile");
          </script>
      <?php  
  } else {
    mysqli_query($conn,$upate_q);
    ?>
    <script>alert("Email successfully updated");
    location.replace("profile");
    </script>
  <?php  
  }
  }
}
if (isset($_POST['name_update'])) {
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $select_query_name = mysqli_query($conn,"select * from login_info where name ='$name' ");
  $upate_q =  "update login_info set name='$name' where username='$uname'";
  if ( mysqli_query($conn,$upate_q)) {
    $_SESSION['name'] = $name;
    ?>
  <script>alert("Name successfully updated");
  location.replace("profile");
  </script>
<?php  
  } else {
    ?>
  <script>alert("something went wrong \n please try again later");
  location.replace("profile");
  </script>
<?php  
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit your profile</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
</head>
<body>
  <nav class="sticky-top noselect ">
  <div id="navbar" class="navbar">
  <div class="logo"><a href="home"><img src="assets/img/logo.png" alt="logo" srcset=""></a></div>
  <div><?php echo $_SESSION['name']; ?></div> 
  <div class="profile-logo">
  <div class="dropdown dropleft">
  <a class="" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <img src="assets/img/user-logo.jpg" alt="" srcset="">
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <form action="logout.php" method="post"><input type="submit" style="outline:none;" name="logout" value="logout" class="dropdown-item text-danger"></form>
  </div>
</div>
  </div>
</div>
</nav>
  <div class="main-div ">
    <div>
  <h4 class="text-center">PROFILE</h4>
  <p class="text-center">edit your account info</p>
    <div class="center-div"><form action="profile" method="post">
      <div class="inputBox">
          <input type="text" name="name" id="name" autocomplete="off" value="<?php echo $fetch_arr['name']; ?>" required>
          <label class="noselect" for="name"> <i class="fas fa-user"></i> Name :</label>
          <div id="errormsgname" class="errormsg"></div>
      </div>
      <div>
          <input id="btnsubmit" name="name_update" class="btn" type="submit" style="margin-bottom:20px" value="Update">
      </div></form><form action="profile" method="post">
      <div class="inputBox">
          <input type="text" name="email" id="email" autocomplete="off" value="<?php echo $fetch_arr['email']; ?>" required >
          <label class="noselect" for="email"> <i class="fas fa-envelope"></i> Email :</label>
          <div class="errormsg" id="errormsgemail"></div>
      </div>
      <div>
          <input id="btnsubmit1" name="submit" class="btn" type="submit" style="margin-bottom:20px" value="Update">
      </div><div class="inputBox">
      <a href="changepass" id="changepass">click here to change password</a> 
      </div>
      </form>
      <div>
      <form action="delacc" method="post"><input type="submit" name="delacc" style="margin-top:20px; background:red; outline:none;" value="delete my Account"></form>
      </div>
    </div>
  </div>
</div>

  

   <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   <script src="assets/Frameworks/bootstrap-4.5.2-dist/js/bootstrap.min.js"></script>
   <script src="assets/js/profile.js"></script>
</body>
</html>