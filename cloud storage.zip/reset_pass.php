<?php
session_start();
define('prevent',TRUE);
include("conn.php");
if (isset($_SESSION['id'])) {
    if(isset($_POST['submit'])){
        $id = $_SESSION['id'];
        $pass = mysqli_real_escape_string($conn , $_POST['password']);;
        $cpass = mysqli_real_escape_string($conn , $_POST['cpass']);;
        $hashed_pass = password_hash($pass , PASSWORD_BCRYPT);
        $update_query = mysqli_query($conn, "update login_info set password = '$hashed_pass' where id='$id'");
        if ($pass == $cpass) {
           if ($update_query) {
            ?>
            <script>alert("Password changed successfully... ");</script>
            <?php
           unset($_SESSION['id']);
           session_destroy();
           header("Location:index");
           } else {
            ?>
            <script>alert("something went wrong \n please try agian later");</script>
            <?php
           }
           
        } else {
            ?>
            <script>alert("password are not matching... \n please try again later");</script>
            <?php
        }
        
    }
} else {
    header("Location:forgotpass");
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change your Password</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">

</head>
<body class="bg3">
    <div class="main_div">
        <div class="center_div">
        <h3 class="text-white text-center mb-1">Change Password</h3>
        <p class="text-white text-center mb-3" style="font-size:13px">Enter you new password  
         </p> 
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" id="form" method="post">
                <div class="inputBox">
                    <input type="password" name="password" id="password" autocomplete="off" required autofocus >
                    <label for="password" class="noselect"><i class="fa fa-lock"></i> Enter Password :</label>
                    <div class="errormsg" id="errormsgpass"></div>
                </div>
                <div class="inputBox">
                    <input type="password" name="cpass" id="cpass" autocomplete="off" required autofocus >
                    <label for="cpass" class="noselect"><i class="fa fa-lock"></i> Confirm Password :</label>
                    <div class="errormsg" id="errormsgcpass"></div>
                </div>
                <div> 
                    <input class="btn btn-block" id="btnsubmit" name="submit" type="submit" value="Change Password">
                </div>
            </form>
        </div>
    </div>
    <script>
$(document).ready(function () {
            $(".errormsg").hide();
            var pass_err = true;
            var cpass_err = true;
            $("#password").keyup(function () { 
                func_pass();
                func_cpass();
            });
            $("#cpass").keyup(function () { 
                func_cpass();
            });
        function func_pass(){
        var pass = $("#password").val();

            if(pass.length < 4){
                $("#errormsgpass").show();
                $("#errormsgpass").html("password is too weak");
                pass_err = false;
                return false;
            } else{
                $("#errormsgpass").hide();
                pass_err = true;
            }
        }
        function func_cpass(){
            var pass = $("#password").val();
            var cpass = $("#cpass").val();

            if (pass != cpass) {
                $("#errormsgcpass").show();
                $("#errormsgcpass").html("password does not match");
                cpass_err = false;
                return false;
            } else {
                $("#errormsgcpass").hide();
                cpass_err = true;
            }
        }

    
    $('#btnsubmit').click(function(){
        function func_pass(){
        var pass = $("#password").val();

            if(pass.length < 4){
                $("#errormsgpass").show();
                $("#errormsgpass").html("password is too weak");
                pass_err = false;
                return false;
            } else{
                $("#errormsgpass").hide();
                pass_err = true;
            }
        }
        func_pass();
        function func_cpass(){
            var pass = $("#password").val();
            var cpass = $("#cpass").val();

            if (pass != cpass) {
                $("#errormsgcpass").show();
                $("#errormsgcpass").html("password does not match");
                cpass_err = false;
                return false;
            } else {
                $("#errormsgcpass").hide();
                cpass_err = true;
            }
        }
        func_cpass();
        if ((pass_err == true) && (cpass_err ==true)) {
            return true;
        }
        else{
            return false;
        }
    });
});
    </script>
</body>
</html>