<?php session_start(); 
define('prevent',TRUE);
include("conn.php");
    if (!isset($_SESSION['name'])) {
      header("location:index");
} 

if (isset($_POST['submit'])) {
        $pass = mysqli_real_escape_string($conn , $_POST['password']);;
        $cpass = mysqli_real_escape_string($conn , $_POST['cpass']);
        $uname = $_SESSION['username'];
        $hashed_pass = password_hash($pass , PASSWORD_BCRYPT);
        $update_query = mysqli_query($conn, "update login_info set password = '$hashed_pass' where username='$uname'");
        if ($pass == $cpass) {
           if ($update_query) {
            ?>
            <script>alert("Password changed successfully... ");location.replace("profile");</script>
            <?php
           } else {
            ?>
            <script>alert("something went wrong \n please try agian later");</script>
            <?php
           }
           
        } else {
            ?>
            <script>alert("password are not matching... \n please try again later");</script>
            <?php
        }
        
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>change Password</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
</head>
<body>
  <nav class="sticky-top noselect ">
  <div id="navbar" class="navbar">
  <div class="logo"><a href="home"><img src="assets/img/logo.png" alt="logo" srcset=""></a></div>
  <div><?php echo $_SESSION['name']; ?></div> 
  <div class="profile-logo">
  <div class="dropdown dropleft">
  <a class="" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <img src="assets/img/user-logo.jpg" alt="" srcset="">
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <form action="logout.php" method="post"><input type="submit" style="outline:none;" name="logout" value="logout" class="dropdown-item text-danger"></form>
  </div>
</div>
  </div>
</div>
</nav>
  
<div class="main-div ">
  <div>
    <h4 class="text-center">PROFILE</h4>
    <p class="text-center">edit your account info</p>
      <div class="center-div">
        <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
        <div class="inputBox">
                    <input type="password" name="password" id="password" autocomplete="off" required autofocus >
                    <label for="password" class="noselect"><i class="fa fa-lock"></i> Enter Password :</label>
                    <div class="errormsg" id="errormsgpass"></div>
                </div>
                <div class="inputBox">
                    <input type="password" name="cpass" id="cpass" autocomplete="off" required autofocus >
                    <label for="cpass" class="noselect"><i class="fa fa-lock"></i> Confirm Password :</label>
                    <div class="errormsg" id="errormsgcpass"></div>
                </div>
                <div> 
                    <input class="btn btn-block" id="btnsubmit" name="submit" type="submit" value="Change Password">
                </div>
        </form>
      </div>
  </div>
</div>

   <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   <script src="assets/Frameworks/bootstrap-4.5.2-dist/js/bootstrap.min.js"></script>
   <script src="assets/js/changepass.js"></script>
</body>
</html>