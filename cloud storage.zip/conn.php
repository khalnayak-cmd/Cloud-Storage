<?php
if (!defined('prevent')) {
    header("Location:index");
}
    $db_server = 'localhost';
    $db_user = 'root';
    $db_password = '';
    $db = 'cloudstorage';

    $conn = mysqli_connect($db_server,$db_user,$db_password,$db);

?>