<?php
session_start();
define('prevent',TRUE);
 include('conn.php');
    if (isset($_POST['submit'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $cpass = mysqli_real_escape_string($conn, $_POST['cpass']);
        
        $hashed_pass = password_hash($password,PASSWORD_BCRYPT);

        $username_check = "select * from login_info where username='$username'";

        $query = mysqli_query($conn,$username_check);

        $username_count = mysqli_num_rows($query);
        
        $select_query_email = mysqli_query($conn,"select * from login_info where email ='$email' ");

        $fetch_arr = mysqli_fetch_assoc($select_query_email);

        if ($email != $fetch_arr['email']) {
          if(mysqli_num_rows($select_query_email) > 0){
            ?>
                <script>
                  alert("email linked to another account \n please choose another email");
                location.replace("profile");
                </script>
            <?php  
        } else {
            if($username_count > 0){
                ?>
                    <script>alert("Username already existed...\n please choose another username ");
                    location.replace("register");
                    </script>
                <?php
                
                
            }
            else{
                if ($password === $cpass) {
                    $insertion_query = "insert into login_info ( name, username, email, password) values ('$name','$username','$email','$hashed_pass')" ;
                    $insert_query = mysqli_query($conn, $insertion_query );
                    mkdir($username);
                    $file_to_write = 'index.php';
                    $content_to_write = "<?php header(\"Location:../index\"); ?>";
                    $file = fopen($username . '/' . $file_to_write,"w");
                    fwrite($file, $content_to_write);
                    fclose($file);
                    ?>
                        <script>
                        alert("account successfully created...");
                        location.replace("home");
                        </script>
                    <?php
                } else {
                    ?>
                        <script>
                        alert("password are not matching...");
                        location.replace("register");
                        </script>
                    <?php
    
                }
                
            }
        }
      } else {
          header("Location:register");
      }
    }
    else{


    header("Location:register");
    }
?>