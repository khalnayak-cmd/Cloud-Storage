<?php session_start(); 
define('prevent',TRUE);
    if (!isset($_SESSION['name'])) {
      header("location:index");
} 
$dir = $_SESSION['username']."/";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome to cloud storage</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
</head>
<body>
  <nav class="sticky-top noselect ">
  <div id="navbar" class="navbar">
  <div class="logo"><a href="home"><img src="assets/img/logo.png" alt="logo" srcset=""></a></div>
  <div> <?php echo $_SESSION['name']; ?></div> 
  <div class="profile-logo">
  <div class="dropdown dropleft">
  <a class="" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <img src="assets/img/user-logo.jpg" alt="" srcset="">
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item text-success" href="profile">Profile</a>
    <div class="dropdown-divider"></div>
    <form action="logout.php" method="post"><input type="submit" style="outline:none;" name="logout" value="logout" class="dropdown-item text-danger"></form>
  </div>
</div>
  </div>
</div>
  </nav>
  <!-- show files in directory php function  -->
<div class="div_center">
  <table class="content-table">
    <thead >
      <tr>
        <th>File Name</th>
        <th class="text-center">Download</th>
        <th class="text-center">Delete</th>
      </tr>
    </thead>
    <tbody>
    <?php

$files = opendir($dir);
while (($file_name = readdir($files)) !== FALSE) {
  if ($file_name != '.' && $file_name != '..') {
  if (!preg_match('/.php/', $file_name)){
    ?>
	  	<tr >
	  		<td class=''><?php echo $file_name; ?></td>
	  		<td class="i-center"><a href="<?php echo $dir.$file_name; ?>" download="<?php echo $file_name ?>" class="text-success"><i class="fas fa-download"></i></a></td>
	  		<td class="i-center"><a href="home?n=<?php echo $file_name; ?>" class="text-danger"><i class="far fa-trash-alt"></i></a></td>
	  	</tr>
    <?php          
  }
  }
}

?>
    </tbody>
  </table>
</div>
<?php

//  deleting file 
if (isset($_GET['n'])) {
  $file_name = $_GET['n'];
  $del_file = "$dir"."$file_name";
  if (file_exists($del_file)) {
    unlink($del_file);
    ?>
    <script>location.replace("home");</script>
    <?php
  } else {
    ?>
    <script>location.replace("home");</script>
    <?php
  }
  
}
// file deleted 
?>

<!-- fab button  -->
<div class="dropdown dropup" id="form_ctrl">
<div class="upload_div " data-toggle="dropdown" id="upload_div" aria-haspopup="true" aria-expanded="false">
<span class="add-icon"><i class="fas fa-plus"></i></span>
</div>
<form class="dropdown-menu p-4" method="post" action="" enctype="multipart/form-data" aria-labelledby="upload_div">
<div class="custom-file">
    <input type="file" class="custom-file-input" name="fileUpload" id="up_file" >
    <label class="custom-file-label" for="up_file">Choose file</label>
  </div>
  <button type="submit" name="submit" class="btn btn-primary">Upload</button>
</form>
</div>

<!--add file upload script-->

<?php
if (isset($_FILES['fileUpload'])) {
  $fileName = $_FILES['fileUpload']['name'];
  $fileSize = $_FILES['fileUpload']['size'];
  $fileTmp = $_FILES['fileUpload']['tmp_name'];
  $fileType = $_FILES['fileUpload']['type'];
  if (file_exists($dir.$fileName)) {
    ?>
      <script>
      alert("Can't upload file \n File already Exists \n please delete Existing File and Try Agian Later...")
      </script>
    <?php
  } else {
if (move_uploaded_file($fileTmp,$dir.$fileName)) {
  ?>
  <script>location.replace("home");</script>
  <?php
} else {
  echo "<script>alert('something went wrong please try again later...');</script>";
}
}
}
?>

   <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   <script src="assets/Frameworks/bootstrap-4.5.2-dist/js/bootstrap.min.js"></script>
   <script src="assets/js/home.js"></script>
</body>
</html>