<?php
    session_start();
    define('prevent',TRUE);
    include("conn.php");
if (isset($_SESSION['name'])) {
    header("location:home");
} else {



    
    if(isset($_POST['submit'])){
        $username = mysqli_real_escape_string($conn , $_POST['username']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);

        $pass_query = "select * from login_info where username = '$username' or email='$username'";
        $query = mysqli_query($conn , $pass_query);
        $user_count = mysqli_num_rows($query);
        if ($user_count > 0) {
            $fetch_arr =  mysqli_fetch_assoc($query);
            $hashed_pass = $fetch_arr['password'];
            if (password_verify($password , $hashed_pass)) {
                $_SESSION['name'] = $fetch_arr['name'];
                $_SESSION['username'] = $fetch_arr['username'];
                header("Location:home");
            } else {
                ?>
            <script>
            alert('password is incorrect...')
            </script>
        <?php
            }
        } 
        else {
            ?>
            <script>
            alert('username or email is incorrect...')
            </script>
        <?php
        }
    }


}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login for Cloud Storage</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">

</head>
<body class="bg">
    <div class="main_div">
        <div class="center_div">
            <h1>Login</h1>
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
                <div class="inputBox">
                    <input type="text" name="username" id="username" autocomplete="off" required autofocus>
                    <label for="username" class="noselect"><i class="fas fa-user-lock"></i> UserName or email</label>
                </div>
                <div class="inputBox">
                    <input type="password" name="password" id="password" autocomplete="off" required>
                    <label for="password" class="noselect"><i class="fas fa-lock"></i> Password</label>
                </div>
                    <div class="custom-control custom-switch">
                      <input type="checkbox" class="custom-control-input" id="showpass">
                      <label class="custom-control-label text-light noselect" for="showpass"> <span id="showhide">Show</span> Password</label>
                    </div>
                    <div id="errormsg"></div>
                <div>
                    <input class="btn btn-block" name="submit" type="submit" value="Login">
                </div>
                <p class="link text-center" style="margin-top:30px;margin-bottom:5px;">forgot password? <a href="forgotpass">click here </a> </p>
                <p class="link text-center">Not Have an Account yet? <a href="register">click here</a> </p>
            </form>
        </div>
    </div>
    <script src="assets/js/main.js"></script>
</body>
</html>