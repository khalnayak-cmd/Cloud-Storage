<?php session_start();
define('prevent',TRUE);
if (isset($_SESSION['name'])) {
    header("Location:home");
} 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Here</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
</head>

<body>
    <div class="main_div">
        <div class="center_div" style="margin-top: 30px;">
            <h1>Register Here</h1>
            <form action="validate.php" method="post" id="form"> 
                <div class="inputBox">
                    <input type="text" name="name" id="name" autocomplete="off" required autofocus>
                    <label class="noselect" for="name"> <i class="fas fa-user"></i> Name :</label>
                    <div id="errormsgname" class="errormsg"></div>
                </div>
                <div class="inputBox">
                    <input type="text" name="username" id="username" autocomplete="off" required >
                    <label class="noselect" for="username"> <i class="fas fa-user-lock"></i> Username :</label>
                    <div class="errormsg" id="errormsgusername"></div>
                    <div id="ajaxuser"></div>
                </div>
                <div class="inputBox">
                    <input type="text" name="email" id="email" autocomplete="off" required >
                    <label class="noselect" for="email"> <i class="fas fa-envelope"></i> Email :</label>
                    <div class="errormsg" id="errormsgemail"></div>
                </div>
                <div class="inputBox">
                    <input type="password" name="password" id="password" autocomplete="off" required >
                    <label class="noselect" for="password"> <i class="fas fa-lock"></i> Password :</label>
                    <div class="errormsg" id="errormsgpass"></div>
                </div>
                <div class="inputBox">
                    <input type="password" name="cpass" id="cpass" autocomplete="off" required >
                    <label class="noselect" for="cpass"><i class="fas fa-lock"></i> Confirm Password :</label>
                    <div class="errormsg" id="errormsgcpass"></div>
                </div>
                <div>
                    <input id="btnsubmit" name="submit" class="btn btn-block" type="submit" value="Sign up">
                </div>
                <p class="link">already have an accout? <a href="index">click Here</a> </p>
            </form>
        </div>
    </div>
    <script src="assets/js/register.js"></script>
</body>
</html>