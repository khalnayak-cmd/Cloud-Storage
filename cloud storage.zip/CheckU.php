<?php
define('prevent',TRUE);
include('conn.php');
if (isset($_POST['username'])) {
    $query = "select * from login_info where username = '".mysqli_real_escape_string($conn, $_POST["username"])."'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        echo '<span>Username has Taken</span>';
    } else {
        echo '<span class="text-success">Username Available</span>';
    }
    
} else {
    header("Location:index");
}
?>