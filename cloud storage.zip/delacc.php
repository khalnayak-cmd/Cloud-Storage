<?php session_start(); 
define('prevent',TRUE);
include("conn.php");
    if (!isset($_SESSION['name'])) {
      header("location:index");
}

$uname = $_SESSION['username'];
$select_q = mysqli_query($conn,"select * from login_info where username='$uname'");
$fetch_arr = mysqli_fetch_assoc($select_q);
$hashed_pass = $fetch_arr['password'];
if (isset($_POST['submit'])) {
    $pass = mysqli_real_escape_string($conn, $_POST['password']);
    if (password_verify($pass,$hashed_pass)) {
        array_map('unlink', glob("$uname/*"));
        rmdir($uname);
        $del_q = mysqli_query($conn, "delete from login_info where username='$uname'");
        if ($del_q) {
            session_destroy();
            ?>
            <script>alert("account deleted successfully...");location.replace("delacc");</script>
            <?php 
        }
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Password to delete Account</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="assets/Frameworks/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="assets/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
</head>
<body>
  <nav class="sticky-top noselect ">
  <div id="navbar" class="navbar">
  <div class="logo"><a href="home"><img src="assets/img/logo.png" alt="logo" srcset=""></a></div>
  <div><?php echo $_SESSION['name']; ?></div> 
  <div class="profile-logo">
  <div class="dropdown dropleft">
  <a class="" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <img src="assets/img/user-logo.jpg" alt="" srcset="">
  </a>

  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <form action="logout.php" method="post"><input type="submit" style="outline:none;" name="logout" value="logout" class="dropdown-item text-danger"></form>
  </div>
</div>
  </div>
</div>
</nav>

<div class="main-div ">
    <div> <br><br>
  <h4 class="text-center">Delete Account</h4>
  <p class="text-center">please Confirm your Password <br> to Delete your Account</p>
    <div class="center-div" style="border:none;"><form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
      <div class="inputBox">
          <input type="password" name="password" id="password" autocomplete="off"  required >
          <label class="noselect" for="password"> <i class="fas fa-envelope"></i> Password :</label>
      </div>
      <div>
          <input id="btnsubmit" name="submit" class="btn " type="submit" style="background:red;"  value="Delete My Account">
      </div>
      </form>
    </div>
  </div>
</div>



 

<script src="assets/Frameworks/JQuery/jquery-3.5.1.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   <script src="assets/Frameworks/bootstrap-4.5.2-dist/js/bootstrap.min.js"></script>
</body>
</html>