$(document).ready(function () {
    
    $(".errormsg").hide();

    var name_err = true;
    var email_err =true;
    // var pass_err = true;
    // var cpass_err = true;



    // name textbox validation
    $("#name").keyup(function () { 
        func_name();
    });
    function func_name(){
        var name_val = $("#name").val();

        if( name_val.length < 3 || name_val.length > 15 ){
            $("#errormsgname").show();
            $("#errormsgname").html("name is invalid");
            name_err = false;
            return false;
        }
        else{
            $("#errormsgname").hide();
        }
    }

    // email address validation with regex
    $("#email").keyup(function () { 
        func_email();
    });

    function func_email(){
        var email = $("#email").val();
        var email_regex = /^[a-z0-9](\.?[a-z0-9]){5,}@g(oogle)?mail\.com$/;

        if (email_regex.test(email)) {
            $("#errormsgemail").hide();
        } else {
            $("#errormsgemail").show();
            $("#errormsgemail").html("please enter valid Gmail address \n (Only Gmail allowed)");
            email_err = false;
            return false;
        }
    }


    // password validation 
    // $("#password").keyup(function () { 
    //     func_pass();
    //     func_cpass();
    // });

    // function func_pass(){
    //     var pass = $("#password").val();

    //     if(pass.length < 4){
    //         $("#errormsgpass").show();
    //         $("#errormsgpass").html("password is too weak");
    //         pass_err = false;
    //         return false;
    //     } else{
    //         $("#errormsgpass").hide();
    //     }
    // }

    // // confirm password validation
    // $("#cpass").keyup(function () { 
    //     func_cpass();
    // });

    // function func_cpass(){
    //     var pass = $("#password").val();
    //     var cpass = $("#cpass").val();

    //     if (pass != cpass) {
    //         $("#errormsgcpass").show();
    //         $("#errormsgcpass").html("password does not match");
    //         cpass_err = false;
    //         return false;
    //     } else {
    //         $("#errormsgcpass").hide();
    //     }
    // }


    $("#btnsubmit").click(function () { 
    name_err = true;
    

    func_name();
    // func_username();
    func_email();
    // func_pass();
    // func_cpass();

    if(name_err == true) {
        return true;
    } else {
        return false;
    }
    });
    $("#btnsubmit1").click(function () { 
        email_err =true;
        
    
        func_name();
        // func_username();
        func_email();
        // func_pass();
        // func_cpass();
    
        if (email_err == true) {
            return true;
        } else {
            return false;
        }
        });
});
