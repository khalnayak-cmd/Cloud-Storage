$(document).ready(function () {
    $(".errormsg").hide();
    var pass_err = true;
    var cpass_err = true;

     $("#password").keyup(function () { 
        func_pass();
        func_cpass();
    });

    function func_pass(){
        var pass = $("#password").val();

        if(pass.length < 4){
            $("#errormsgpass").show();
            $("#errormsgpass").html("password is too weak");
            pass_err = false;
            return false;
        } else{
            $("#errormsgpass").hide();
        }
    }

    // confirm password validation
    $("#cpass").keyup(function () { 
        func_cpass();
    });

    function func_cpass(){
        var pass = $("#password").val();
        var cpass = $("#cpass").val();

        if (pass != cpass) {
            $("#errormsgcpass").show();
            $("#errormsgcpass").html("password does not match");
            cpass_err = false;
            return false;
        } else {
            $("#errormsgcpass").hide();
        }
    }


    $('#btnsubmit').click(function () { 
        pass_err = true;
        cpass_err = true;
        func_cpass();
        func_pass();

        if ((pass_err == true) && (cpass_err == true)) {
            return true;
        } else {
            return false;
        }
        
    });

});