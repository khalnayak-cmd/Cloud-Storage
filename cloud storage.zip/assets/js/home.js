$(document).ready(function () {
    $(".upload_div").click(function () { 
        $(".upload_div").toggleClass("active-fab");
    });
    $('body').click(function () { 
    var xyz = $("#form_ctrl").hasClass('show');
    if (!xyz) {
        $('#upload_div').attr('class', 'upload_div');
    }
    });



    $(".custom-file-input").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
      });
});