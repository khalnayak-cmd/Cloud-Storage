$(document).ready(function(){
    $("#showpass").change(function(){
     // Check the checkbox state
     if($(this).is(':checked')){
      // Changing type attribute
      $("#password").attr("type","text");
      // Change the Text
      $("#showhide").text("Hide");
     }else{
      // Changing type attribute
      $("#password").attr("type","password");
      // Change the Text
      $("#showhide").text("Show");
     }
    });
   });